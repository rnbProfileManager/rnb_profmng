package com.rnb.profmng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfmngApplicationTests {

	@Test
	void contextLoads() {
	}

}
